SRC=ar
TGT=en
LANG=lev
BPESIZE=1000

fairseq-train \
    data-bin/bpe-${BPESIZE}-${LANG}-${SRC}-${TGT} \
    --save-dir checkpoints/bpe-${BPESIZE}-${LANG}-${SRC}-${TGT} \
    --tensorboard-logdir tensorboard/bpe-${BPESIZE}-${LANG}-${SRC}-${TGT} \
    --source-lang $SRC --target-lang $TGT \
    --arch transformer --share-all-embeddings \
    --encoder-normalize-before --decoder-normalize-before \
    --dropout 0.4 --attention-dropout 0.2 --relu-dropout 0.2 \
    --weight-decay 0.0001 \
    --label-smoothing 0.2 --criterion label_smoothed_cross_entropy \
    --optimizer adam --adam-betas '(0.9, 0.98)' --clip-norm 0 \
    --lr-scheduler inverse_sqrt --warmup-updates 4000 --warmup-init-lr 1e-7 \
    --lr 5e-4 --min-lr 1e-9 \
    --max-tokens 4000 \
    --update-freq 16 \
    --no-progress-bar --no-epoch-checkpoints --valid-subset valid \
    --eval-bleu --eval-bleu-remove-bpe='sentencepiece' \
    --best-checkpoint-metric bleu --maximize-best-checkpoint-metric --eval-tokenized-bleu \
    --fp16 --keep-best-checkpoints 3
