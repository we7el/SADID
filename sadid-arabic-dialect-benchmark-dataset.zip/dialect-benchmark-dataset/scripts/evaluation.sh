SRC=ar
TGT=en
LANG=lev
BPESIZE=1000
EXPERIMENT=bpe-${BPESIZE}-${LANG}-${SRC}-${TGT}
fairseq-generate data-bin/${EXPERIMENT} --path checkpoints/${EXPERIMENT}/checkpoint_best.pt --remove-bpe=sentencepiece

SRC=ar
TGT=en
LANG=egy
BPESIZE=5000
EXPERIMENT=bpe-${BPESIZE}-${LANG}-${SRC}-${TGT}
fairseq-generate data-bin/${EXPERIMENT} --path checkpoints/${EXPERIMENT}/checkpoint_best.pt --remove-bpe=sentencepiece
