SRC=ar
TGT=en
LANG=lev
BPESIZE=1000
TRAIN_MINLEN=1
TRAIN_MAXLEN=250
SPM=/bpe/sentencepiece
SPM_TRAIN=/scripts/spm_train.py
SPM_ENCODE=/scripts/spm_encode.py
TRAININ=/data/training-files
EVALIN=/data/benchmark-set
OUT=/experiments/bpe-${BPESIZE}-${LANG}-${SRC}-${TGT}
BINARIZED=/data-bin/bpe-${BPESIZE}-${LANG}-${SRC}-${TGT}

mkdir -p experiments/bpe-${BPESIZE}-${LANG}-${SRC}-${TGT}

python $SPM_TRAIN \
    --input=$TRAININ/train.$SRC,$TRAININ/train.$TGT \
    --model_prefix=$SPM/sentencepiece.bpe_${LANG}_${BPESIZE} \
    --vocab_size=$BPESIZE \
    --character_coverage=1.0 \
    --model_type=bpe

python $SPM_ENCODE \
    --model $SPM/sentencepiece.bpe_${LANG}_${BPESIZE}.model \
    --output_format=piece \
    --inputs $TRAININ/train.$SRC $TRAININ/train.$TGT \
    --outputs $OUT/train.$SRC $OUT/train.$TGT \
    --min-len $TRAIN_MINLEN --max-len $TRAIN_MAXLEN
for SPLIT in "val" "test"; do \
    python $SPM_ENCODE \
        --model $SPM/sentencepiece.bpe_${LANG}_${BPESIZE}.model \
        --output_format=piece \
        --inputs $EVALIN/$SPLIT.$SRC $EVALIN/$SPLIT.$TGT \
        --outputs $OUT/$SPLIT.$SRC $OUT/$SPLIT.$TGT
done

fairseq-preprocess \
    --source-lang $SRC --target-lang $TGT \
    --trainpref $OUT/train --validpref $OUT/val --testpref $OUT/test \
    --destdir $BINARIZED \
    --joined-dictionary
done
